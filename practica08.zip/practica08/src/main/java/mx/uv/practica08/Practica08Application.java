package mx.uv.practica08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica08Application {

	public static void main(String[] args) {
		SpringApplication.run(Practica08Application.class, args);
	}

}
