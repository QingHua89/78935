@jakarta.xml.bind.annotation.XmlSchema(namespace = "t4is.uv.mx/saludos", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package xx.mx.uv.consumo.wsdl;
